package com.example.myfeverete

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
