import 'dart:convert';

BlogPost blogPostFromJson(String str) => BlogPost.fromJson(json.decode(str));

class BlogPost {
  BlogPost({
    required this.blogs,
  });

  List<Blog> blogs;

  factory BlogPost.fromJson(Map<String, dynamic> json) => BlogPost(
        blogs: List<Blog>.from(json["blogs"].map((x) => Blog.fromJson(x))),
      );
}

class Blog {
  Blog({
    required this.id,
    required this.title,
    required this.description,
    required this.coverPhoto,
    required this.categories,
    required this.author,
  });

  int id;
  String title;
  String description;
  String coverPhoto;
  List<String> categories;
  Author author;

  factory Blog.fromJson(Map<String, dynamic> json) => Blog(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        coverPhoto: json["cover_photo"],
        categories: List<String>.from(json["categories"].map((x) => x)),
        author: Author.fromJson(json["author"]),
      );
}

class Author {
  Author({
    required this.id,
    required this.name,
    required this.avatar,
    required this.profession,
  });

  int id;
  String name;
  String avatar;
  String profession;

  factory Author.fromJson(Map<String, dynamic> json) => Author(
        id: json["id"],
        name: json["name"],
        avatar: json["avatar"],
        profession: json["profession"],
      );
}
