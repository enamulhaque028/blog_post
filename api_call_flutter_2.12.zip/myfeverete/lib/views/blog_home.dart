import 'package:flutter/material.dart';
import 'package:myfeverete/ui/new_shops.dart';
import 'package:myfeverete/ui/trending_products.dart';
import '../model/model.dart';
import '../service/services.dart';
import '../ui/trending_sellers.dart';

class BlogHome extends StatefulWidget {
  @override
  _BlogHomeState createState() => _BlogHomeState();
}

class _BlogHomeState extends State<BlogHome> {
  BlogPost blogPost = new BlogPost(blogs: []);
  var isLoading = true;

  @override
  void initState() {
    Webservice().fetchPosts().then((data) {
      setState(() {
        blogPost = data;
        isLoading = false;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var blogInfo = blogPost.blogs;
    return Scaffold(
      backgroundColor: Colors.white,
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Trending Sellers
                    Text(
                      "Trending Sellers",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      height: 180,
                      child: ListView.builder(
                          itemCount: blogInfo.length,
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            return TrendingSellers(
                              imgUrl: blogInfo[index].coverPhoto.toString(),
                              title: blogInfo[index].title.toString(),
                              description:
                                  blogInfo[index].description.toString(),
                              avatar: blogInfo[index].author.avatar.toString(),
                              author: blogInfo[index].author.name,
                              profession: blogInfo[index].author.profession,
                            );
                          }),
                    ),

                    // Trending Products
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        "Trending Products",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                    Container(
                      height: 160,
                      child: ListView.builder(
                          itemCount: blogInfo.length,
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            return TrendingProducts(
                              imgUrl: blogInfo[index].coverPhoto.toString(),
                              title: blogInfo[index].title.toString(),
                              description:
                                  blogInfo[index].description.toString(),
                              avatar: blogInfo[index].author.avatar.toString(),
                              author: blogInfo[index].author.name,
                              profession: blogInfo[index].author.profession,
                            );
                          }),
                    ),

                    // New Shops
                    Container(
                      padding: EdgeInsets.only(top: 20.0),
                      child: ListView.builder(
                          itemCount: blogInfo.length,
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          itemBuilder: (context, index) {
                            return NewShops(
                              imgUrl: blogInfo[index].coverPhoto.toString(),
                              title: blogInfo[index].title.toString(),
                              description:
                                  blogInfo[index].description.toString(),
                              avatar: blogInfo[index].author.avatar.toString(),
                              author: blogInfo[index].author.name,
                              profession: blogInfo[index].author.profession,
                            );
                          }),
                    ),

                    // New Arrivals
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        "New Arrivals",
                        style: TextStyle(
                            fontSize: 16,
                            //color: Colors.black54,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    Container(
                      height: 160,
                      child: ListView.builder(
                          itemCount: blogInfo.length,
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            return TrendingProducts(
                              imgUrl: blogInfo[index].coverPhoto.toString(),
                              title: blogInfo[index].title.toString(),
                              description:
                                  blogInfo[index].description.toString(),
                              avatar: blogInfo[index].author.avatar.toString(),
                              author: blogInfo[index].author.name,
                              profession: blogInfo[index].author.profession,
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
